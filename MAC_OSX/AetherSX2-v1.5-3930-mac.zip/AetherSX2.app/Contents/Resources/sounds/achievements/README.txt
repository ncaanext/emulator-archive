lbsubmit.wav: https://freesound.org/people/Eponn/sounds/636656/
unlock.wav and message.wav are from https://github.com/RetroAchievements/RAInterface
